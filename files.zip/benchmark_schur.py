"""Benchmark the three Schur complement methods on the FEM block system.

The three functions below are your exercise_7 implementations with one change:
the split point n1 is an argument instead of A.shape[0] // 2, because the FEM
system has (n-2)**2 interior and 4*n-4 boundary dofs. Adding

    def naive_schur_complement(A, n1=None):
        n = A.shape[0] // 2 if n1 is None else n1

to your own three files lets you import them here instead.
"""

import time

import numpy as np
from numpy.typing import NDArray
from scipy.linalg import lu_factor, lu_solve

from make_schur_system import make_schur_system


def _blocks(A: NDArray, n1: int):
    return A[:n1, :n1], A[:n1, n1:], A[n1:, :n1], A[n1:, n1:]


def naive_schur_complement(A: NDArray, n1: int):
    """7 i) Explicit inverse."""
    A_11, A_12, A_21, A_22 = _blocks(A, n1)
    A_11_inv = np.linalg.inv(A_11)
    return A_22 - A_21 @ A_11_inv @ A_12


def linear_eq_schur_complement(A: NDArray, n1: int):
    """7 ii) Solve A_11 X = A_12, one solve with n2 right-hand sides."""
    A_11, A_12, A_21, A_22 = _blocks(A, n1)
    sol = np.linalg.solve(A_11, A_12)
    return A_22 - A_21 @ sol


def partial_gauss_schur_complement(A: NDArray, n1: int):
    """7 iii) One LU factorisation of A_11, reused via the transposed solve.

    Uses scipy's lu_factor here; swap in your exercise_6 lu_decomposition and
    rebuild lu = L - I + U as in your original file.
    """
    A_11, A_12, A_21, A_22 = _blocks(A, n1)
    lu, piv = lu_factor(A_11)
    X = lu_solve((lu, piv), A_21.T, trans=1)
    M = X.T                      # M = A_21 @ inv(A_11)
    return A_22 - M @ A_12


METHODS = [
    ("naive (inv)", naive_schur_complement),
    ("linear eq (solve)", linear_eq_schur_complement),
    ("partial Gauss (LU)", partial_gauss_schur_complement),
]


def time_method(fn, A, n1, repeats=3):
    best = np.inf
    S = None
    for _ in range(repeats):
        A_copy = A.copy()
        t0 = time.perf_counter()
        S = fn(A_copy, n1)
        best = min(best, time.perf_counter() - t0)
    return best, S


def main(grid_sizes=(10, 20, 30, 40, 50), repeats=3):
    header = f"{'n':>4} {'dofs':>6} {'n1':>6} " + " ".join(
        f"{name:>20}" for name, _ in METHODS
    )
    print(header)
    print("-" * len(header))

    for n in grid_sizes:
        A11, _, _, _, K = make_schur_system(n, dense=True)
        n1 = A11.shape[0]

        times, results = [], []
        for _, fn in METHODS:
            dt, S = time_method(fn, K, n1, repeats)
            times.append(dt)
            results.append(S)

        print(f"{n:>4} {K.shape[0]:>6} {n1:>6} "
              + " ".join(f"{dt * 1e3:>17.3f} ms" for dt in times))

        # Accuracy: compare against the LU result, which is the best
        # conditioned of the three.
        ref = results[-1]
        scale = np.linalg.norm(ref)
        errs = [np.linalg.norm(S - ref) / scale for S in results]
        print(f"{'':>4} {'':>6} {'rel err':>6} "
              + " ".join(f"{e:>20.3e}" for e in errs))


if __name__ == "__main__":
    main()
